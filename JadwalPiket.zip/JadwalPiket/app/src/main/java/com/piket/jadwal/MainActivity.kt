package com.piket.jadwal

import android.Manifest
import android.app.AlarmManager
import android.content.ClipboardManager
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.divider.MaterialDivider
import com.google.android.material.textfield.TextInputLayout
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private val indonesia = Locale.forLanguageTag("id-ID")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<MaterialToolbar>(R.id.toolbar).setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_share -> shareSchedule()
                R.id.action_import -> importDialog()
            }
            true
        }
        findViewById<View>(R.id.fabAdd).setOnClickListener { memberDialog(null) }
        findViewById<View>(R.id.rowMe).setOnClickListener { chooseMe() }
        findViewById<View>(R.id.rowTime).setOnClickListener { chooseTime() }
        findViewById<View>(R.id.btnTest).setOnClickListener {
            if (!Reminder.show(this, "Notifikasi uji", "Pengingat piket sudah aktif di HP ini.")) {
                toast("Izin notifikasi belum diberikan")
            }
        }
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        Reminder.schedule(this)
        refresh()
    }

    private fun refresh() {
        val members = Store.members(this)
        val me = Store.me(this)
        val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val onDuty = members.filter { today in it.days }.map { it.name }

        findViewById<TextView>(R.id.todayDate).text = SimpleDateFormat("EEEE, d MMMM", indonesia).format(Date())
        findViewById<TextView>(R.id.todayNames).text =
            if (onDuty.isEmpty()) "Tidak ada petugas hari ini" else onDuty.joinToString(" · ")
        findViewById<View>(R.id.todayBadge).visibility =
            if (me != null && me in onDuty) View.VISIBLE else View.GONE

        setRow(findViewById(R.id.rowMe), "Saya adalah", me ?: "Belum dipilih")
        setRow(findViewById(R.id.rowTime), "Jam pengingat", "%02d.%02d".format(Store.hour(this), Store.minute(this)))

        val week = findViewById<LinearLayout>(R.id.weekList)
        week.removeAllViews()
        Store.WEEK.forEachIndexed { i, d ->
            if (i > 0) week.addView(MaterialDivider(this))
            val names = members.filter { d in it.days }.joinToString(", ") { it.name }
            val row = newRow(week, Store.dayName(d), names.ifEmpty { "—" })
            if (d == today) row.setBackgroundColor(getColor(R.color.teal_soft))
        }

        val list = findViewById<LinearLayout>(R.id.memberList)
        list.removeAllViews()
        if (members.isEmpty()) newRow(list, "", "Belum ada anggota. Ketuk \"Tambah anggota\" untuk mulai.")
        members.forEachIndexed { i, m ->
            if (i > 0) list.addView(MaterialDivider(this))
            val days = Store.WEEK.filter { it in m.days }.joinToString(", ") { Store.dayShort(it) }
            val title = if (m.name == me) "${m.name} (saya)" else m.name
            newRow(list, title, days.ifEmpty { "Belum ada hari" }).setOnClickListener { memberDialog(m) }
        }
    }

    private fun newRow(parent: LinearLayout, title: String, sub: String): View {
        val v = layoutInflater.inflate(R.layout.item_row, parent, false)
        setRow(v, title, sub)
        parent.addView(v)
        return v
    }

    private fun setRow(v: View, title: String, sub: String) {
        v.findViewById<TextView>(R.id.title).apply {
            text = title
            visibility = if (title.isEmpty()) View.GONE else View.VISIBLE
        }
        v.findViewById<TextView>(R.id.subtitle).text = sub
    }

    private fun memberDialog(edit: Member?) {
        val v = layoutInflater.inflate(R.layout.dialog_member, null)
        val nameLayout = v.findViewById<TextInputLayout>(R.id.nameLayout)
        val nameInput = v.findViewById<EditText>(R.id.nameInput)
        val chips = v.findViewById<ChipGroup>(R.id.dayChips)
        Store.WEEK.forEach { d ->
            val chip = layoutInflater.inflate(R.layout.item_day_chip, chips, false) as Chip
            chip.text = Store.dayName(d)
            chip.tag = d
            chip.isChecked = edit?.days?.contains(d) == true
            chips.addView(chip)
        }
        nameInput.setText(edit?.name ?: "")

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(if (edit == null) "Tambah anggota" else "Ubah anggota")
            .setView(v)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
        if (edit != null) builder.setNeutralButton("Hapus") { _, _ -> confirmDelete(edit) }
        val dialog = builder.show()

        // Own click handler so the dialog stays open when validation fails.
        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener {
            val name = nameInput.text.toString().trim()
            val members = Store.members(this)
            if (name.isEmpty()) {
                nameLayout.error = "Nama wajib diisi"
                return@setOnClickListener
            }
            if (members.any { it.name.equals(name, ignoreCase = true) && it.name != edit?.name }) {
                nameLayout.error = "Nama sudah dipakai"
                return@setOnClickListener
            }
            val days = (0 until chips.childCount)
                .map { chips.getChildAt(it) as Chip }
                .filter { it.isChecked }
                .map { it.tag as Int }
                .toSet()
            val updated = Member(name, days)
            if (edit == null) {
                Store.saveMembers(this, members + updated)
            } else {
                Store.saveMembers(this, members.map { if (it.name == edit.name) updated else it })
                if (Store.me(this) == edit.name) Store.setMe(this, name)
            }
            dialog.dismiss()
            refresh()
        }
    }

    private fun confirmDelete(m: Member) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Hapus ${m.name}?")
            .setMessage("Anggota ini akan dihapus dari jadwal piket.")
            .setPositiveButton("Hapus") { _, _ ->
                Store.saveMembers(this, Store.members(this).filter { it.name != m.name })
                if (Store.me(this) == m.name) Store.setMe(this, null)
                refresh()
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun chooseMe() {
        val names = Store.members(this).map { it.name }
        if (names.isEmpty()) {
            toast("Tambah anggota dulu")
            return
        }
        val current = Store.me(this)?.let { names.indexOf(it) } ?: -1
        MaterialAlertDialogBuilder(this)
            .setTitle("Siapa pemilik HP ini?")
            .setSingleChoiceItems(names.toTypedArray(), current) { d, i ->
                Store.setMe(this, names[i])
                d.dismiss()
                refresh()
            }
            .show()
    }

    private fun chooseTime() {
        val picker = MaterialTimePicker.Builder()
            .setTimeFormat(TimeFormat.CLOCK_24H)
            .setHour(Store.hour(this))
            .setMinute(Store.minute(this))
            .setTitleText("Jam pengingat")
            .build()
        picker.addOnPositiveButtonClickListener {
            Store.setTime(this, picker.hour, picker.minute)
            Reminder.schedule(this)
            refresh()
        }
        picker.show(supportFragmentManager, "time")
    }

    private fun shareSchedule() {
        val members = Store.members(this)
        if (members.isEmpty()) {
            toast("Belum ada jadwal untuk dibagikan")
            return
        }
        val msg = "Jadwal piket kita. Pasang aplikasi Jadwal Piket, buka menu ⋮ → Impor jadwal, " +
            "lalu tempel pesan ini.\n\n" + Store.exportCode(members)
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, msg)
        startActivity(Intent.createChooser(send, "Bagikan jadwal"))
    }

    private fun importDialog() {
        val pad = (24 * resources.displayMetrics.density).toInt()
        val input = EditText(this).apply {
            hint = "Tempel pesan jadwal di sini"
            minLines = 3
        }
        val box = FrameLayout(this).apply {
            setPadding(pad, pad / 3, pad, 0)
            addView(input)
        }
        val clip = getSystemService(ClipboardManager::class.java).primaryClip
            ?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        if (clip != null && Store.CODE in clip) input.setText(clip)

        MaterialAlertDialogBuilder(this)
            .setTitle("Impor jadwal")
            .setMessage("Jadwal di HP ini akan diganti dengan jadwal yang ditempel.")
            .setView(box)
            .setPositiveButton("Impor") { _, _ ->
                val list = Store.importCode(input.text.toString())
                if (list == null) {
                    toast("Kode jadwal tidak valid")
                } else {
                    Store.saveMembers(this, list)
                    if (list.none { it.name == Store.me(this) }) Store.setMe(this, null)
                    refresh()
                    toast("Jadwal diimpor: ${list.size} anggota")
                    if (Store.me(this) == null) chooseMe()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun askPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            !getSystemService(AlarmManager::class.java).canScheduleExactAlarms() &&
            !Store.askedExact(this)
        ) {
            Store.setAskedExact(this)
            MaterialAlertDialogBuilder(this)
                .setTitle("Izinkan pengingat tepat waktu")
                .setMessage("Agar notifikasi muncul tepat di jam yang dipilih, aktifkan \"Alarm & pengingat\" untuk aplikasi ini.")
                .setPositiveButton("Buka pengaturan") { _, _ ->
                    startActivity(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
                }
                .setNegativeButton("Nanti", null)
                .show()
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
