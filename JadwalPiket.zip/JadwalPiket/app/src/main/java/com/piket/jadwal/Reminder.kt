package com.piket.jadwal

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import java.util.Calendar

object Reminder {
    private const val CHANNEL = "piket_reminder"

    /** Sets one alarm for the next reminder time; AlarmReceiver re-arms it every day. */
    fun schedule(c: Context) {
        val am = c.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            c, 0, Intent(c, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, Store.hour(c))
            set(Calendar.MINUTE, Store.minute(c))
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    fun notifyIfOnDuty(c: Context) {
        val me = Store.me(c) ?: return
        val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        val duty = Store.members(c).filter { today in it.days }.map { it.name }
        if (me !in duty) return
        val others = duty - me
        val day = Store.dayName(today)
        val text = if (others.isEmpty()) "Hari ini ($day) kamu kebagian piket."
        else "Hari ini ($day) kamu piket bersama ${others.joinToString(", ")}."
        show(c, "Waktunya piket, $me!", text)
    }

    /** Returns false when the notification permission is missing. */
    fun show(c: Context, title: String, text: String): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        val nm = c.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Pengingat piket", NotificationManager.IMPORTANCE_HIGH)
                .apply { description = "Muncul di hari kamu kebagian piket" }
        )
        val open = PendingIntent.getActivity(
            c, 1, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_notif)
            .setColor(c.getColor(R.color.teal))
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
        return true
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Reminder.notifyIfOnDuty(c)
        Reminder.schedule(c)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) = Reminder.schedule(c)
}
