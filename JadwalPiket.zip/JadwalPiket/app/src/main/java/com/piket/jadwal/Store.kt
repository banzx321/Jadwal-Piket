package com.piket.jadwal

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.Base64
import java.util.Calendar

/** days = Calendar.DAY_OF_WEEK values (1 = Minggu ... 7 = Sabtu). */
data class Member(val name: String, val days: Set<Int>)

object Store {
    const val CODE = "PIKET1:"

    // Urutan minggu Indonesia: Senin dulu.
    val WEEK = listOf(
        Calendar.MONDAY, Calendar.TUESDAY, Calendar.WEDNESDAY, Calendar.THURSDAY,
        Calendar.FRIDAY, Calendar.SATURDAY, Calendar.SUNDAY
    )

    fun dayName(d: Int) = when (d) {
        Calendar.MONDAY -> "Senin"
        Calendar.TUESDAY -> "Selasa"
        Calendar.WEDNESDAY -> "Rabu"
        Calendar.THURSDAY -> "Kamis"
        Calendar.FRIDAY -> "Jumat"
        Calendar.SATURDAY -> "Sabtu"
        else -> "Minggu"
    }

    fun dayShort(d: Int) = dayName(d).take(3)

    private fun prefs(c: Context) = c.getSharedPreferences("piket", Context.MODE_PRIVATE)

    fun members(c: Context): List<Member> =
        runCatching { parse(prefs(c).getString("members", "[]")!!) }.getOrDefault(emptyList())

    fun saveMembers(c: Context, list: List<Member>) =
        prefs(c).edit().putString("members", toJson(list).toString()).apply()

    fun me(c: Context): String? = prefs(c).getString("me", null)
    fun setMe(c: Context, name: String?) = prefs(c).edit().putString("me", name).apply()

    fun hour(c: Context) = prefs(c).getInt("hour", 6)
    fun minute(c: Context) = prefs(c).getInt("minute", 30)
    fun setTime(c: Context, h: Int, m: Int) =
        prefs(c).edit().putInt("hour", h).putInt("minute", m).apply()

    fun askedExact(c: Context) = prefs(c).getBoolean("asked_exact", false)
    fun setAskedExact(c: Context) = prefs(c).edit().putBoolean("asked_exact", true).apply()

    fun exportCode(list: List<Member>): String =
        CODE + Base64.getEncoder().encodeToString(toJson(list).toString().toByteArray())

    /** Accepts a whole pasted chat message; returns null if no valid code is found. */
    fun importCode(text: String): List<Member>? = runCatching {
        val b64 = Regex("PIKET1:([A-Za-z0-9+/=]+)").find(text)!!.groupValues[1]
        parse(String(Base64.getDecoder().decode(b64)))
            .filter { it.name.isNotBlank() }
            .distinctBy { it.name.lowercase() }
    }.getOrNull()

    private fun toJson(list: List<Member>) = JSONArray().apply {
        list.forEach { m -> put(JSONObject().put("n", m.name).put("d", JSONArray(m.days.sorted()))) }
    }

    private fun parse(json: String): List<Member> {
        val a = JSONArray(json)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            val d = o.getJSONArray("d")
            Member(o.getString("n").trim(), (0 until d.length()).map { d.getInt(it) }.filter { it in 1..7 }.toSet())
        }
    }
}
